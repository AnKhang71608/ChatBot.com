const GEMINI_API_KEY = "AIzaSyBQ2JGs29a1AaK1QCiVfjqm9YhB5UXdqlg";
const API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key=" + GEMINI_API_KEY;

let chats = [[]];
let currentChatIndex = 0;

async function fetchGeminiResponse(parts) {
    try {
        const response = await fetch(API_URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                contents: [
                    {
                        parts: parts
                    }
                ]
            })
        });

        const data = await response.json();

        if (data.candidates && data.candidates.length > 0) {
            return data.candidates[0].content.parts[0].text;
        } else {
            return "AI không trả lời.";
        }

    } catch (error) {
        console.error("Lỗi API:", error);
        return "Rất tiếc, đã có lỗi xảy ra khi kết nối với AI.";
    }
}

async function sendMessage() {
    const input = document.getElementById("userInput");
    const fileInput = document.getElementById("fileInput");
    const chatBox = document.getElementById("chatBox");

    const text = input.value.trim();
    const file = fileInput.files[0];

    if (text === "" && !file) return;

    let fileData = null;
    if (file) {
        fileData = await readFileAsBase64(file);
    }

    chats[currentChatIndex].push({ role: "user", text, file: fileData ? { mimeType: file.type, data: fileData } : null });
    input.value = "";
    fileInput.value = "";
    renderChat();

    const loadingId = "loading-" + Date.now();
    const loadingDiv = document.createElement("div");
    loadingDiv.className = "message bot";
    loadingDiv.id = loadingId;
    loadingDiv.innerText = "Đang suy nghĩ...";
    chatBox.appendChild(loadingDiv);
    chatBox.scrollTop = chatBox.scrollHeight;

    const parts = [];
    if (text) parts.push({ text });
    if (fileData) parts.push({ inlineData: { mimeType: file.type, data: fileData } });

    const botResponse = await fetchGeminiResponse(parts);

    const loadingElement = document.getElementById(loadingId);
    if (loadingElement) loadingElement.remove();

    chats[currentChatIndex].push({
        role: "bot",
        text: botResponse,
        file: null
    });

    renderChatWithTyping(botResponse);
}

function readFileAsBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result.split(',')[1]); // Remove data: prefix
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

function renderChat() {
    const chatBox = document.getElementById("chatBox");
    chatBox.innerHTML = "";

    chats[currentChatIndex].forEach(msg => {
        const div = document.createElement("div");
        div.className = "message " + msg.role;

        if (msg.file) {
            if (msg.file.mimeType.startsWith('image/')) {
                const img = document.createElement("img");
                img.src = `data:${msg.file.mimeType};base64,${msg.file.data}`;
                img.style.maxWidth = "100%";
                img.style.borderRadius = "10px";
                div.appendChild(img);
            } else {
                const link = document.createElement("a");
                link.href = `data:${msg.file.mimeType};base64,${msg.file.data}`;
                link.download = "uploaded_file";
                link.innerText = "📎 Tệp tin đã tải lên";
                link.style.color = "#00d4ff";
                div.appendChild(link);
            }
        }

        if (msg.text) {
            const textDiv = document.createElement("div");
            textDiv.innerHTML = marked.parse(msg.text);
            div.appendChild(textDiv);
        }

        chatBox.appendChild(div);
    });

    chatBox.scrollTop = chatBox.scrollHeight;
}

function renderChatWithTyping(botText) {
    const chatBox = document.getElementById("chatBox");
    const div = document.createElement("div");
    div.className = "message bot";
    chatBox.appendChild(div);

    let index = 0;
    const typingSpeed = 50; // ms per character

    function typeWriter() {
        if (index < botText.length) {
            div.innerText += botText.charAt(index);
            index++;
            chatBox.scrollTop = chatBox.scrollHeight;
            setTimeout(typeWriter, typingSpeed);
        } else {
            // After typing, render Markdown
            div.innerHTML = marked.parse(botText);
        }
    }

    typeWriter();
}

function newChat() {
    chats.push([]);
    currentChatIndex = chats.length - 1;
    renderHistory();
    renderChat();
}

function renderHistory() {
    const history = document.getElementById("history");
    history.innerHTML = "";
    chats.forEach((chat, index) => {
        const div = document.createElement("div");
        div.className = "history-item";
        let preview = chat.length > 0 ? chat[0].text.substring(0, 20) + "..." : "Chat mới " + (index + 1);
        if (chat.length > 0 && chat[0].file) preview = "📎 " + preview;
        div.innerText = preview;
        div.onclick = () => {
            currentChatIndex = index;
            renderChat();
        };
        history.appendChild(div);
    });
}

document.getElementById("userInput").addEventListener("keypress", (e) => {
    if (e.key === "Enter") sendMessage();
});

function showLogin() { document.getElementById("authModal").style.display = "flex"; }
function showRegister() { document.getElementById("authModal").style.display = "flex"; }
function closeModal() { document.getElementById("authModal").style.display = "none"; }
function handleAuth() { alert("Đã xác thực!"); closeModal(); }

function toggleMusic() {
    const music = document.getElementById("backgroundMusic");
    const toggleBtn = document.getElementById("musicToggle");
    if (music.paused) {
        // Fade in
        music.volume = 0;
        music.play();
        toggleBtn.textContent = "🎵 Music: On";
        fadeIn(music);
    } else {
        // Fade out
        fadeOut(music, () => {
            music.pause();
            toggleBtn.textContent = "🎵 Music: Off";
        });
    }
}

function fadeIn(audio) {
    const targetVolume = 0.2;
    const fadeStep = 0.01;
    const fadeInterval = 50;
    let currentVolume = audio.volume;
    const fade = setInterval(() => {
        currentVolume += fadeStep;
        if (currentVolume >= targetVolume) {
            audio.volume = targetVolume;
            clearInterval(fade);
        } else {
            audio.volume = currentVolume;
        }
    }, fadeInterval);
}

function fadeOut(audio, callback) {
    const fadeStep = 0.01;
    const fadeInterval = 50;
    let currentVolume = audio.volume;
    const fade = setInterval(() => {
        currentVolume -= fadeStep;
        if (currentVolume <= 0) {
            audio.volume = 0;
            clearInterval(fade);
            if (callback) callback();
        } else {
            audio.volume = currentVolume;
        }
    }, fadeInterval);
}

function stopMusic() {
    const music = document.getElementById("backgroundMusic");
    const playBtn = document.getElementById("playMusic");
    const stopBtn = document.getElementById("stopMusic");
    music.pause();
    music.currentTime = 0;
    playBtn.style.display = "inline";
    stopBtn.style.display = "none";
}

function loadMusic() {
    const fileInput = document.getElementById("musicFile");
    const music = document.getElementById("backgroundMusic");
    const playBtn = document.getElementById("playMusic");
    if (fileInput.files[0]) {
        const fileURL = URL.createObjectURL(fileInput.files[0]);
        music.src = fileURL;
        playBtn.style.display = "inline";
    }
}

window.addEventListener('load', () => {
    const music = document.getElementById("backgroundMusic");
    music.volume = 0;
    music.play().then(() => {
        document.getElementById("musicToggle").textContent = "🎵 Music: On";
        fadeIn(music);
    }).catch(() => {
        // Autoplay may be blocked by browser
        document.getElementById("musicToggle").textContent = "🎵 Music: Off";
    });
});

renderHistory();